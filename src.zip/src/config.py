MAX_INTERVAL_TO_RANDOMIC_WHEIT = 0.8
MIN_INTERVAL_TO_RANDOMIC_WHEIT = -0.8
LEARNING_COEFFICIENT = 0.0001
EPOCH = 10000
PERCEPTRON_IN = 2
PERCEPTRON_OUT = 1
ABALONE_CSV_PATH = '/Users/luizvictorsantos/Projects/perceptron/src/utils/datasets/abalone.csv'
IN_ABALONE_CSV_PATH = '/Users/luizvictorsantos/Projects/perceptron/src/utils/datasets/abalone_in.csv'
ABALONE_OUT = '/Users/luizvictorsantos/Projects/perceptron/src/utils/datasets/abalone_out.csv'
ABALONE_OUT_BINARY_REPRESENTATION = '/Users/luizvictorsantos/Projects/perceptron/src/utils/datasets/abalone_out_binary_representation.csv'
ABALONE_IN = '/Users/luizvictorsantos/Projects/perceptron/src/utils/datasets/abalone_in.csv'
ABALONE_IN_SELECTED_SAMPLES = '/Users/luizvictorsantos/Projects/perceptron/src/utils/datasets/abalone_in_selected_samples.csv'
ABALONE_ORIGINAL_DATASET = '/Users/luizvictorsantos/Projects/perceptron/src/utils/datasets/abalone_original_dataset.csv'
ABALONE_PREDICT = '/Users/luizvictorsantos/Projects/perceptron/src/utils/datasets/abalone_predict.csv'
ABALONE_PREDICT_10000_EPOCHS = '/Users/luizvictorsantos/Projects/perceptron/src/utils/datasets/abalone_predict_10000_epochs.csv'

