from src.controllers.perceptron_runner import PerceptronRunner


def main():
    perceptron_runner = PerceptronRunner()
    perceptron_runner.runner()


if __name__ == "__main__":
    main()
